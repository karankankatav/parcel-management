
document.addEventListener('DOMContentLoaded', function() {
  const trackingForm = document.getElementById('trackingForm');
  const trackingResult = document.getElementById('trackingResult');
  const statusMessage = document.getElementById('statusMessage');

  trackingForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting

    // Simulate tracking status based on booking ID
    const bookingId = document.getElementById('bookingId').value;
    const status = trackParcel(bookingId);

    // Display tracking status
    displayTrackingStatus(status);
  });

  function trackParcel(bookingId) {
    // Simulated tracking status
    const trackingStatus = {
      '123456789012': 'In Transit',
      '987654321098': 'Out for Delivery',
      '567890123456': 'Delivered',
      // Add more tracking statuses as needed
    };
    // Return tracking status based on booking ID
    return trackingStatus[bookingId] || 'Unknown';
  }

  function displayTrackingStatus(status) {
    trackingResult.style.display = 'block';
    statusMessage.textContent = `Status: ${status}`;
  }
});

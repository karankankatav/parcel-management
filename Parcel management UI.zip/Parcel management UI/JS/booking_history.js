document.addEventListener('DOMContentLoaded', function() {
    const username = document.getElementById('username');
    const bookingBody = document.getElementById('bookingBody');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const logoutBtn = document.getElementById('logoutBtn');
  
    // Mock user data for demonstration
    const userData = {
      username: 'John Doe',
      bookings: [
        {
          customerId: 'C123456',
          bookingId: 'B123456789',
          bookingDate: '2024-05-10',
          receiverName: 'Alice',
          deliveredAddress: '123 Main St, City',
          amount: '$50',
          status: 'Delivered'
        },
        // Add more booking details as needed
      ]
    };
  
    // Populate user details
    username.textContent = userData.username;
  
    // Populate booking details
    function populateBookingDetails(index) {
      const booking = userData.bookings[index];
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${booking.customerId}</td>
        <td>${booking.bookingId}</td>
        <td>${booking.bookingDate}</td>
        <td>${booking.receiverName}</td>
        <td>${booking.deliveredAddress}</td>
        <td>${booking.amount}</td>
        <td>${booking.status}</td>
      `;
      bookingBody.innerHTML = ''; // Clear previous data
      bookingBody.appendChild(row);
    }
  
    let currentIndex = 0;
    populateBookingDetails(currentIndex);
  
    // Navigation buttons functionality
    prevBtn.addEventListener('click', function() {
      if (currentIndex > 0) {
        currentIndex--;
        populateBookingDetails(currentIndex);
      }
    });
  
    nextBtn.addEventListener('click', function() {
      if (currentIndex < userData.bookings.length - 1) {
        currentIndex++;
        populateBookingDetails(currentIndex);
      }
    });
  
    // Logout functionality (replace with actual logout logic)
    logoutBtn.addEventListener('click', function() {
        window.location.href = '../index.html';
    });
  }); 

document.addEventListener('DOMContentLoaded', function() {
  // Get username from localStorage
  const username = localStorage.getItem('username');
  const welcomeMessage = document.getElementById('welcomeMessage');

  // Display welcome message with username
  if (username) {
    welcomeMessage.textContent = 'Welcome ' + username + '!';
  }

  // Logout functionality
  const logoutBtn = document.getElementById('logoutBtn');
  logoutBtn.addEventListener('click', function(event) {
    event.preventDefault();
    // Clear user details from localStorage
    localStorage.removeItem('username');
    // Redirect to login page
    window.location.href = '../index.html';
  });
});

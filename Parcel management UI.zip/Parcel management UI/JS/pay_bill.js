document.addEventListener('DOMContentLoaded', function() {
  const welcomeMessage = document.getElementById('welcomeMessage');
  const logoutBtn = document.getElementById('logoutBtn');
  const paymentDetails = document.getElementById('paymentDetails');
  const payNowBtn = document.getElementById('payNowBtn');
  const backToHomeBtn = document.getElementById('backToHomeBtn');
  const cardDetails = document.getElementById('cardDetails');
  const makePaymentBtn = document.getElementById('makePaymentBtn');
  const paymentMessage = document.getElementById('paymentMessage');

  // Get username from localStorage and display welcome message
  const username = localStorage.getItem('username');
  if (username) {
    welcomeMessage.textContent = 'Welcome ' + username + '!';
  }

  // Logout functionality
  logoutBtn.addEventListener('click', function() {
    localStorage.removeItem('username');
    window.location.href = '../index.html';
  });

  // Show card details section when Pay Now button is clicked
  payNowBtn.addEventListener('click', function() {
    paymentDetails.style.display = 'none';
    cardDetails.style.display = 'block';
  });

  // Back to home page when Back to Home button is clicked
  backToHomeBtn.addEventListener('click', function() {
    window.location.href = 'booking_service.html';
  });

  // Handle payment when Make Payment button is clicked
  makePaymentBtn.addEventListener('click', function() {
    // Simulate payment process
    // For simplicity, just display a success message
    const BookingId = generateBookingId()
    paymentMessage.innerHTML = `<p class="success-message">Payment Successful! with Booking Id ${BookingId} </p>`;
    paymentMessage.style.display = 'block';
    // Redirect to invoice page after a short delay (for demonstration)
    setTimeout(function() {
      window.location.href = 'invoice.html';
    }, 2000);
  });


  function generateBookingId() {
    // Generate a random username (for demonstration purposes)
    return 'Booking_' + Math.random().toString(36).substr(2, 9);
  }
});

document.addEventListener('DOMContentLoaded', function() {
    const username = document.getElementById('username');
    const contactNumber = document.getElementById('contactNumber');
    const mailId = document.getElementById('mailId');
    const address = document.getElementById('address');
    const logoutBtn = document.getElementById('logoutBtn');
  
    // Mock user data for demonstration
    const userData = {
      username: 'John Doe',
      contactNumber: '123-456-7890',
      mailId: 'support@example.com',
      address: '123 Main Street, City, Country'
    };
  
    // Populate user details
    username.textContent = userData.username;
    contactNumber.textContent = userData.contactNumber;
    mailId.textContent = userData.mailId;
    address.textContent = userData.address;
  
    // Logout functionality (replace with actual logout logic)
    logoutBtn.addEventListener('click', function() {
        window.location.href = '../index.html';
    });
  });
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    
  
    loginForm.addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent the form from submitting
      const loginType = document.querySelector('input[name="logintype"]:checked').value;

        redirectToLoginPage(loginType);
    });
  
    function redirectToLoginPage(loginType) {
      // Simulate redirect to dashboard (replace 'dashboard.html' with your actual dashboard page)
      if(loginType=='cust') {
        window.location.href = '/HTML/customer_login.html';
      }
      else{
        window.location.href = '/HTML/officer_login.html';
      }
    }
  });
  
  
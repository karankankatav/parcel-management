
document.addEventListener('DOMContentLoaded', function() {
  const registrationForm = document.getElementById('registrationForm');
  const acknowledgmentDiv = document.getElementById('acknowledgment');

  registrationForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting

    const password = document.getElementById('password').value.trim();
    const confpassword = document.getElementById('confirmPassword').value.trim();
    const errordiv = document.getElementById('error');

    if(password!=confpassword) {
      errordiv.style.display = "block";
      errordiv.innerHTML = `<p>Password not matched!</p>`
      return
    }

    errordiv.style.display = "none"
    // Generate random username
    const username = generateUsername();

    // Display registration acknowledgment
    const registerButton = document.getElementById('registerbtn').disabled = true;

    displayAcknowledgment(username);
  });

  function generateUsername() {
    // Generate a random username (for demonstration purposes)
    return 'User_' + Math.random().toString(36).substr(2, 9);
  }

  function displayAcknowledgment(username) {
    // Get input values
    const customerName = document.getElementById('customerName').value;
    const email = document.getElementById('email').value;

    // Display acknowledgment message
    acknowledgmentDiv.innerHTML = `
      <p class="success_message">Consumer Registration successful.</p>
      <p><strong>Customer Username:</strong> ${username}</p>
      <p><strong>Customer Name:</strong> ${customerName}</p>
      <p><strong>Email:</strong> ${email}</p>
      <button id= "loginbtn" style="width:70px" type="button">Login</button>
    `;

    const loginbtn = document.getElementById('loginbtn');
    loginbtn.addEventListener('click', function(event) {
      event.preventDefault();
      localStorage.removeItem('username');
      window.location.href = '../index.html';
    });
  }

});



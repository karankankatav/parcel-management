
document.addEventListener('DOMContentLoaded', function() {
  const invoiceDetails = document.getElementById('invoiceDetails');
  const printBtn = document.getElementById('printBtn');

  // Mock data for demonstration
  const invoiceData = {
    receiverName: 'John Doe',
    receiverAddress: '123 Main Street',
    receiverPin: '12345',
    receiverMobile: '123-456-7890',
    parcelWeight: '500',
    parcelContents: 'Electronics',
    deliveryType: 'Standard',
    packingPreference: 'Standard Packaging',
    pickupTime: '2024-05-12 09:00 AM',
    dropoffTime: '2024-05-13 10:00 AM',
    serviceCost: '$50',
    paymentTime: '2024-05-13 11:30 AM'
  };

  // Populate invoice details
  document.getElementById('receiverName').value = invoiceData.receiverName;
  document.getElementById('receiverAddress').value = invoiceData.receiverAddress;
  document.getElementById('receiverPin').value = invoiceData.receiverPin;
  document.getElementById('receiverMobile').value = invoiceData.receiverMobile;
  document.getElementById('parcelWeight').value = invoiceData.parcelWeight;
  document.getElementById('parcelContents').value = invoiceData.parcelContents;
  document.getElementById('deliveryType').value = invoiceData.deliveryType;
  document.getElementById('packingPreference').value = invoiceData.packingPreference;
  document.getElementById('pickupTime').value = invoiceData.pickupTime;
  document.getElementById('dropoffTime').value = invoiceData.dropoffTime;
  document.getElementById('serviceCost').value = invoiceData.serviceCost;
  document.getElementById('paymentTime').value = invoiceData.paymentTime;

  // Print button functionality
  printBtn.addEventListener('click', function() {
    window.print();
  });
}); 

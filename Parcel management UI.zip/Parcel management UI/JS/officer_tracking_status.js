
document.addEventListener('DOMContentLoaded', function() {
  const searchBtn = document.getElementById('searchBtn');
  const trackingResult = document.getElementById('trackingResult');
  const statusMessage = document.getElementById('statusMessage');

  searchBtn.addEventListener('click', function() {
    // Simulated tracking status based on customer and booking ID
    const customerId = document.getElementById('customerId').value;
    const bookingId = document.getElementById('bookingId').value;
    const status = trackParcel(customerId, bookingId);

    // Display tracking status
    displayTrackingStatus(status);
  });

  function trackParcel(customerId, bookingId) {
    // Simulated tracking status
    const trackingStatus = {
      'C123456': {
        'B987654321': 'In Transit',
        'B123456789': 'Out for Delivery',
        // Add more booking IDs as needed
      },
      'C789012': {
        'B654321098': 'Delivered',
        // Add more booking IDs as needed
      },
      // Add more customer IDs as needed
    };
    // Return tracking status based on customer and booking ID
    return trackingStatus[customerId] ? trackingStatus[customerId][bookingId] || 'Unknown' : 'Unknown';
  }

  function displayTrackingStatus(status) {
    trackingResult.style.display = 'block';
    statusMessage.textContent = `Status: ${status}`;
  }
});

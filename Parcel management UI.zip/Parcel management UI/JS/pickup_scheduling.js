
document.addEventListener('DOMContentLoaded', function() {
  const searchBtn = document.getElementById('searchBtn');
  const pickupDetails = document.getElementById('pickupDetails');
  const saveBtn = document.getElementById('saveBtn');
  const message = document.getElementById('message');

  searchBtn.addEventListener('click', function() {
    // Simulated pickup details retrieval based on booking ID
    const bookingId = document.getElementById('bookingId').value;
    const pickupInfo = getPickupDetails(bookingId);

    // Display pickup details if found
    if (pickupInfo) {
      displayPickupDetails(pickupInfo);
    } else {
      showErrorMessage('Booking ID not found.');
    }
  });

  saveBtn.addEventListener('click', function() {
    // Simulated save operation
    const pickupDate = document.getElementById('pickupDate').value;
    const pickupTime = document.getElementById('pickupTime').value;

    // Validate pickup date and time
    if (pickupDate && pickupTime) {
      showMessage('Pickup scheduled successfully.');
    } else {
      showErrorMessage('Please select a date and time for pickup.');
    }
  });

  function getPickupDetails(bookingId) {
    // Simulated pickup details retrieval
    const pickupDetails = {
      'B123456789': {
        bookingId: 'B123456789',
        pickupDate: '2024-05-15',
        pickupTime: '10:00'
      },
      'B987654321': {
        bookingId: 'B987654321',
        pickupDate: '2024-05-16',
        pickupTime: '09:30'
      },
      // Add more pickup details as needed
    };
    // Return pickup details based on booking ID
    return pickupDetails[bookingId];
  }

  function displayPickupDetails(pickupInfo) {
    pickupDetails.style.display = 'block';
    document.getElementById('pickupDate').value = pickupInfo.pickupDate;
    document.getElementById('pickupTime').value = pickupInfo.pickupTime;
  }

  function showMessage(msg) {
    message.textContent = msg;
    message.style.color= 'green'
    message.style.display = 'block';
  }

  function showErrorMessage(msg) {
    message.textContent = msg;
    message.style.color= 'red'
    message.style.display = 'block';
  }
});

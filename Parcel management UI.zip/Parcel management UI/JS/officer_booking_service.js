
document.addEventListener('DOMContentLoaded', function() {
  const bookingForm = document.getElementById('bookingForm');
  const errorDiv = document.getElementById('error');
  const successDiv = document.getElementById('success')

  bookingForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting

    // Perform custom validation here
    // For simplicity, let's assume all required fields are filled
    redirectToPayment();
     
    // If validation succeeds, simulate successful booking
    displaySuccessMessage();
  });

  function displaySuccessMessage() {
    successDiv.innerHTML = `<p class="success-message">Booking successful!</p>`;
  }

  function redirectToPayment() {
    window.location.href = '/HTML/pay_bill.html';
  }

});
